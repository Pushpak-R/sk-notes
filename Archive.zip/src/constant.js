export const ADD = 'ADD';
export const EDIT = 'EDIT';
export const VIEW = 'VIEW';